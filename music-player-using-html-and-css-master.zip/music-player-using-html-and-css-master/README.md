# music-player-using-html-and-css

this is a music player,  created by only html and css.
# https://kk095.github.io/music-player-using-html-and-css/
